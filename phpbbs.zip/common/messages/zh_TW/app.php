<?php
/**
 * 中文繁体语言包
 * @authors Amos (735767227@qq.com)
 * @date    2017-05-03 14:55:10
 * @version $Id$
 */

return [
    'whatisthis' => '你好啊中國'
];
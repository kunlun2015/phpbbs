<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'fileSavePath' => dirname(dirname(__DIR__)).'/upload/',
    'uploadSaveDirs' => array('avatar', 'banner', 'posts'),
    'imgUrl' => 'http://localhost/personal/phpbbs/upload/',
    'logRootPath' => dirname(dirname(__DIR__)).'/log/',
];

<?php
return [
    'adminEmail' => 'admin@example.com',
    'siteName'   => 'kl系统',
    'backendFileSavePath' => dirname(__DIR__).'/web/upload/',
    'uploadSaveDirs' => array('avatar')
];

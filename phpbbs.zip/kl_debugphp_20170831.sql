/*
 Navicat MySQL Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : localhost:3306
 Source Schema         : yii

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 31/08/2017 10:35:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for kl_category
-- ----------------------------
DROP TABLE IF EXISTS `kl_category`;
CREATE TABLE `kl_category`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '父菜单id',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '类别名称',
  `href` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '链接',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '排序，越大越靠前',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态，0正常，1禁用',
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '简介',
  `create_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作者',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '类别分组结构' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_category
-- ----------------------------
INSERT INTO `kl_category` VALUES (4, 3, '后台1', '', 0, 0, '', '2017-07-31 14:46:22', 'kunlun');
INSERT INTO `kl_category` VALUES (10, 0, 'PHP', '', 0, 0, 'php栏目', '2017-08-01 15:39:06', 'kunlun');
INSERT INTO `kl_category` VALUES (11, 10, '基础', '', 0, 0, 'php基础', '2017-08-01 15:52:54', 'kunlun');
INSERT INTO `kl_category` VALUES (12, 10, '高级', '', 0, 0, 'php高级', '2017-08-01 15:53:15', 'kunlun');
INSERT INTO `kl_category` VALUES (13, 10, '进阶', '', 0, 0, 'php进阶', '2017-08-01 15:53:36', 'kunlun');
INSERT INTO `kl_category` VALUES (14, 10, '应用', '', 0, 0, 'php应用', '2017-08-01 15:53:57', 'kunlun');
INSERT INTO `kl_category` VALUES (15, 10, '安全', '', 0, 0, 'php安全', '2017-08-01 15:54:33', 'kunlun');
INSERT INTO `kl_category` VALUES (16, 0, 'MySQL', '', 0, 0, 'MySQL 栏目', '2017-08-03 14:17:25', 'kunlun');

-- ----------------------------
-- Table structure for kl_function
-- ----------------------------
DROP TABLE IF EXISTS `kl_function`;
CREATE TABLE `kl_function`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '父菜单id',
  `icon` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '菜单图标',
  `name` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '功能名称',
  `controller` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '控制器',
  `method` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '方法',
  `url` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '跳转链接',
  `groupid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '所在分组id',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '菜单状态，默认0，1禁用',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '菜单分组内排序',
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '备注信息',
  `create_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作者',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '功能管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_function
-- ----------------------------
INSERT INTO `kl_function` VALUES (12, 0, 'fa fa-file-picture-o', 'banner管理', 'banner', 'index', '', 7, 0, 0, '轮播图管理', '2017-04-24 11:59:17', 'root');
INSERT INTO `kl_function` VALUES (13, 0, 'fa fa-tree', '分类管理', 'category', 'index', '', 7, 0, 0, '网站分类结构管理', '2017-04-26 15:21:46', 'root');
INSERT INTO `kl_function` VALUES (14, 0, 'fa fa-newspaper-o', '文章管理', 'post', 'index', '', 7, 0, 0, '文章管理', '2017-08-01 09:39:55', 'root');

-- ----------------------------
-- Table structure for kl_function_group
-- ----------------------------
DROP TABLE IF EXISTS `kl_function_group`;
CREATE TABLE `kl_function_group`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '分组标题',
  `sort` tinyint(4) NOT NULL DEFAULT 0 COMMENT '分组排序',
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '分组说明',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态，0正常，1禁用',
  `create_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作者',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '功能分组' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_function_group
-- ----------------------------
INSERT INTO `kl_function_group` VALUES (7, 'phpstudybbs', 1, 'php学习论坛，分享php项目经验等', 0, '2017-04-24 11:54:46', 'root');

-- ----------------------------
-- Table structure for kl_login_psd
-- ----------------------------
DROP TABLE IF EXISTS `kl_login_psd`;
CREATE TABLE `kl_login_psd`  (
  `uid` int(10) UNSIGNED NOT NULL COMMENT '用户uid',
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '登录密码',
  `encrypt` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '加密字符串',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '密码登陆表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_login_psd
-- ----------------------------
INSERT INTO `kl_login_psd` VALUES (1, '9b59a5326fb44191e38995ba9562cd915c68fa934863ab25d8fea9d1b4426b54', 'WsSuV3xa');

-- ----------------------------
-- Table structure for kl_post_basic
-- ----------------------------
DROP TABLE IF EXISTS `kl_post_basic`;
CREATE TABLE `kl_post_basic`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '第一级分类id',
  `lid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '最后一级分类id',
  `author` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '作者',
  `authorid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '作者id',
  `title` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '文章标题',
  `tag` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '标签，多个标签逗号隔开',
  `abstract` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '摘要',
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '封面图片',
  `display_order` tinyint(1) NOT NULL DEFAULT 0 COMMENT '显示顺序， 默认0正常，1置顶1，2置顶2，3置顶3',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态，0正常，-2禁用， -1审核中',
  `views` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '浏览量',
  `comments` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '评论量',
  `likes` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '点赞量',
  `unlikes` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '不喜欢点赞数量',
  `create_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '文章基本信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_post_basic
-- ----------------------------
INSERT INTO `kl_post_basic` VALUES (1, 10, 11, 'kunlun', 1, 'test', '', '摘要', 'posts/2017/08/UCqXenDQcvgC20170804095100.jpg', 0, 0, 0, 0, 0, 0, '2017-08-04 09:51:07');

-- ----------------------------
-- Table structure for kl_posts
-- ----------------------------
DROP TABLE IF EXISTS `kl_posts`;
CREATE TABLE `kl_posts`  (
  `bid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'post_basic id',
  `fid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '第一级分类id',
  `lid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '最后一级分类id',
  `title` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '文章标题',
  `posts` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '内容'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '文章内容信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_posts
-- ----------------------------
INSERT INTO `kl_posts` VALUES (1, 10, 11, 'test', '<p>内容</p>');

-- ----------------------------
-- Table structure for kl_root_user
-- ----------------------------
DROP TABLE IF EXISTS `kl_root_user`;
CREATE TABLE `kl_root_user`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `realname` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '真实姓名',
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '头像路径',
  `mobile` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '手机号码',
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '登陆密码',
  `encrypt` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '加密字符串',
  `login_times` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录次数',
  `last_login_time` datetime(0) DEFAULT NULL COMMENT '上次登陆时间',
  `last_login_ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '上次登录ip',
  `remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '用户状态，0正常，1禁用',
  `create_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统管理员' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_root_user
-- ----------------------------
INSERT INTO `kl_root_user` VALUES (1, 'root', '昆仑', NULL, '18679601581', '9b59a5326fb44191e38995ba9562cd915c68fa934863ab25d8fea9d1b4426b54', 'WsSuV3xa', 1, '2017-08-31 10:28:23', '127.0.0.1', NULL, 0, '2017-08-31 10:25:02');

-- ----------------------------
-- Table structure for kl_slide_banner
-- ----------------------------
DROP TABLE IF EXISTS `kl_slide_banner`;
CREATE TABLE `kl_slide_banner`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) NOT NULL DEFAULT 0 COMMENT '分类id',
  `title` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '标题',
  `href` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '跳转链接',
  `picture` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '图片',
  `begin_time` datetime(0) NOT NULL COMMENT '开始时间',
  `end_time` datetime(0) NOT NULL COMMENT '结束时间',
  `sort` int(11) NOT NULL DEFAULT 0 COMMENT '排序，越大越靠前',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态，0正常，1禁用',
  `create_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作者',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '轮播图' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_slide_banner
-- ----------------------------
INSERT INTO `kl_slide_banner` VALUES (3, 1, '测试banner', 'http://www.lovehpy.com', 'banner/2017/04/MFewppQdLhxI20170426135506.png', '2017-04-26 00:00:00', '2017-08-31 00:00:00', 0, 0, '2017-04-26 13:55:08', 'kunlun');

-- ----------------------------
-- Table structure for kl_user_menu_authority
-- ----------------------------
DROP TABLE IF EXISTS `kl_user_menu_authority`;
CREATE TABLE `kl_user_menu_authority`  (
  `uid` int(10) UNSIGNED NOT NULL COMMENT '用户uid',
  `authority` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '用户权限',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户后台菜单权限' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_user_menu_authority
-- ----------------------------
INSERT INTO `kl_user_menu_authority` VALUES (1, '7|12,13,14|j1_1,12,13,14');

-- ----------------------------
-- Table structure for kl_users
-- ----------------------------
DROP TABLE IF EXISTS `kl_users`;
CREATE TABLE `kl_users`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `realname` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '真实姓名',
  `sex` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1男，2女',
  `mobile` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '手机号码',
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户头像',
  `login_times` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录次数',
  `last_login_time` datetime(0) DEFAULT NULL COMMENT '上次登陆时间',
  `last_login_ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '上次登录ip',
  `remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '用户状态，0等待激活，1正常，2禁用',
  `create_at` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kl_users
-- ----------------------------
INSERT INTO `kl_users` VALUES (1, 'kunlun', '昆仑', 0, '18679601581', NULL, 1, '2017-08-31 10:18:58', '127.0.0.1', NULL, 0, '2017-08-30 14:20:29');

SET FOREIGN_KEY_CHECKS = 1;

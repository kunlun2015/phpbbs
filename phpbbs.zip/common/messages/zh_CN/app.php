<?php
/**
 * 中文简体语言包
 * @authors Amos (735767227@qq.com)
 * @date    2017-04-21 13:41:33
 * @version $Id$
 */

return [
    'whatisthis' => '你好啊'
];
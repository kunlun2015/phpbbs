<?php
return [
    'adminEmail' => 'admin@example.com',
    'siteName'   => 'kl系统',    
    'defaultAvatar' => 'static/pages/media/profile/profile_user.jpg'
];

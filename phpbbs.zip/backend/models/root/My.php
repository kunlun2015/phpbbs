<?php
/**
 * 
 * @authors Kunlun (szhcool1129@sina.com)
 * @date    2017-04-09 20:28:17
 * @version $Id$
 */

namespace backend\models\root;
use yii\base\Model;

class My extends \backend\models\CommonModel{

}